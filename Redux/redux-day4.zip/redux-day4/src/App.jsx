import './App.css'
import PostList from './features/posts/PostsList'

function App() {
  return (
    <>
      <h2>The PostList APP</h2>
      <PostList/>
    </>
  )
}

export default App
